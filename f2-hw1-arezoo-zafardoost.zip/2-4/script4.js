// برنامه ای بنویسید که یک رشته (رضا)از ورودی دریافت کند و معکوس ان را برگرداند.

const name = "رضا";

let reverseName = 
name.split('').reverse().join('');

console.log("رشته معکوس شده"+reverseName )