// تایپ داده های زیر را در کنسول چاپ کنید


let num = 4+"4";
console.log(typeof num);

let hom = 2222n;
console.log( typeof hom);

let word = ("reza");
console.log(typeof word);

let num1 = 12 && 124;
console.log(typeof num1);


let num2 = 12 || 124;
console.log(typeof num2);

let not = null;
console.log(typeof not);

let num3 = 2*2;
console.log(typeof num3);

let num4 = 2*"2";
console.log(typeof num4);
