// تابعی بنویسید که به عنوان ورودی یک ارایه بگیرد و تایپ تمام اعضای ارایه را برگرداند.

function typer(hello) {

    for (let i=0; i<hello.length; i++){


        console.log(typeof hello[i]);

        

    } 

    }

 typer([1,"hi",true,{name:"arezoo"},null])


 

